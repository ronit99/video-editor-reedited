# OptiVideoEditor-for-iOS

OptiVideoEditor - This is a professional video edit app, it's an easy & practical video editing app for expertise & beginners.This is an awesome video editor with free video trimmer. Video slide transitions, slow & fast motion, video trimming, video merge, filters and more features, to help you to make great video show in one minute!

![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-iOS/master/ScreenShots/VideoEditor.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-iOS/master/ScreenShots/AddImage.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-iOS/master/ScreenShots/AddMusic.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-iOS/master/ScreenShots/MergeVideo.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-iOS/master/ScreenShots/SlowFastMotion.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-iOS/master/ScreenShots/Transition.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-iOS/master/ScreenShots/AddText.png)

## Features

- ##### Video trim

- ##### Audio

- ##### Video merge

- ##### Slow and fast motion

- ##### Video transition

- ##### Text and image

- ##### Filters
