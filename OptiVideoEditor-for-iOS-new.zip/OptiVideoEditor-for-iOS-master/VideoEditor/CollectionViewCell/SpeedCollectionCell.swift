//
//  SpeedCollectionCell.swift
//  VideoEditor
//
//  Created by Optisol on 21/07/19.
//  Copyright © 2019 optisol. All rights reserved.
//

import UIKit

class SpeedCollectionCell: UICollectionViewCell {

    @IBOutlet weak var vw_back: UIView!
    @IBOutlet weak var lbl_speedsec: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
