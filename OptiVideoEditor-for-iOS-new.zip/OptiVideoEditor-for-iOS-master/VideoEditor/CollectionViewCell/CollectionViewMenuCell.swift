//
//  CollectionViewMenuCell.swift
//  VideoEditor
//
//  Created by Optisol on 21/07/19.
//  Copyright © 2019 optisol. All rights reserved.
//
//

import UIKit

class CollectionViewMenuCell: UICollectionViewCell {

    @IBOutlet weak var imgvw_Menu: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
