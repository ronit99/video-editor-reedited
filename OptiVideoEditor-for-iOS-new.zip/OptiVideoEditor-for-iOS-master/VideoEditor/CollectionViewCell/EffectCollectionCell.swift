//
//  EffectCollectionCell.swift
//  VideoEditor
//
//  Created by Optisol on 21/07/19.
//  Copyright © 2019 optisol. All rights reserved.
//

import UIKit

class EffectCollectionCell: UICollectionViewCell {

    @IBOutlet weak var effect_Imgvw: UIImageView!
    @IBOutlet weak var lbl_effectName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
